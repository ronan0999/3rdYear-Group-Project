package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.*;

import android.os.Bundle;

public class Homepage extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        button = (Button) findViewById(R.id.button4);
        button2 = (Button) findViewById(R.id.button5);
        button3  = (Button) findViewById(R.id.button6);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMedicalhistory();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            openReviewPage();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPayPal();
            }
        });


    }
    public void openReviewPage(){
        Intent intent = new Intent(this,reviewpage.class);
        startActivity(intent);
    }

    public void openPayPal(){
        Intent intent2 = new Intent(this,activity_PayPal.class);
        startActivity(intent2);
    }

    public void openMedicalhistory(){
        Intent intent3 = new Intent(this,medical_history.class);
        startActivity(intent3);
    }
}
