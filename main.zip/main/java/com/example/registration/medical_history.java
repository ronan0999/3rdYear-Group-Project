package com.example.registration;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class medical_history extends AppCompatActivity {

    private Button commit;
    private Button button;

    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    private EditText editText5;

    //database
    private diabetes bloodpressure;
    private diabetes skinfold;
    private diabetes insulin;
    private diabetes bmi;
    private diabetes age;

    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_history);

        //database
        bloodpressure = new diabetes();
        skinfold = new diabetes();
        insulin = new diabetes();
        bmi = new diabetes();
        age = new diabetes();
        database= FirebaseDatabase.getInstance();
        reference = database.getReference("Diabetes");


        button = findViewById(R.id.button10);
        editText1 = findViewById(R.id.editText10);
        editText2 = findViewById(R.id.editText11);
        editText3 = findViewById(R.id.editText12);
        editText4 = findViewById(R.id.editText13);
        editText5 = findViewById(R.id.editText14);

        commit = findViewById(R.id.button9);
        commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bloodpressure.setBloodpressure(editText1.getText().toString());
                reference.child(bloodpressure.getBloodpressure()).setValue(bloodpressure);

                skinfold.setSkinfold(editText2.getText().toString());
                reference.child(skinfold.getSkinfold()).setValue(skinfold);

                insulin.setInsulin(editText3.getText().toString());
                reference.child(insulin.getInsulin()).setValue(insulin);

                bmi.setBmi(editText4.getText().toString());
                reference.child(bmi.getBmi()).setValue(bmi);

                age.setAge(editText5.getText().toString());
                reference.child(age.getAge()).setValue(age).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(medical_history.this,"added to database",Toast.LENGTH_LONG).show();
                        }

                        else{
                            Toast.makeText(medical_history.this,"error has occured",Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHeartDisease();
            }
        });
    }

    public void openHeartDisease(){
        Intent intent = new Intent(this, HeartDisease.class);
        startActivity(intent);
    }
}
