package com.example.registration;

public class payment {

    private String amount;

    public payment() {
    }

    public payment(String amount) {
        this.amount = amount;
    }

    //getters and setters
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
