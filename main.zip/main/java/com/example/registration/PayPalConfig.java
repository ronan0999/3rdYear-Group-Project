package com.example.registration;

public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "AQYaGe5R9bnOkvU_Pxzr88Q2Wq7HDrdo2wJ6zRc35Ig-Cq30WUPBSkEEfAqlDnunbpQXJvgHr2_Ew-wy";

}
